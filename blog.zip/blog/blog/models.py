#coding:utf-8

from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
# Create your models here.

class Category(models.Model):
    """
    django 要求我们必须继承 models.Model 类，
    Category 只需要一个简单的分类名 name 就可以了。

    CharField 指定了 name 的数据类型，
    CharField 是字符型，
    max_length 指定其最大长度，
    超过这个长度的分类名就不能被存入数据库。

    当然 django 还为我们提供了各种各样的类型，
    如日期时间类型 DateTimeField、
    整数类型 IntegerField 等等。
    django 内置的类型全部类型可查看文档：
    https://docs.djangoproject.com/en/1.10/ref/models/fields/#field-types
    """
    name = models.CharField(max_length=100)

class Tag(models.Model):
    """
    标签 Tag 也比较简单，
    和 Category 一样。
    再次强调一定要继承 models.Model 类！
    """
    name = models.CharField(max_length=100)

class Post(models.Model):
    """
    文章的数据库表稍微复杂一点，主要是涉及的字段更多。
    """
    title = models.CharField(max_length=70)
    body = models.TextField()
    created_time = models.DateTimeField()
    modified_time = models.DateTimeField()
    excerpt = models.CharField(max_length=200, blank=True)
    category = models.ForeignKey(Category)
    tags = models.ManyToManyField(Tag, blank=True)
    author = models.ForeignKey(User)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('blog:detail', kwargs={'pk': self.pk})
