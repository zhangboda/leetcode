#coding:utf-8
from django.shortcuts import render, get_object_or_404
from .models import Post,Category
from comments.forms import CommentForm
import markdown2

def detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    post.body = markdown.markdown(post.body,
                                  extensions=[
                                     'markdown2.extensions.extra',
                                     'markdown2.extensions.codehilite',
                                     'markdown2.extensions.toc',
                                  ])
    form = CommentForm()
    comment_list = post.comment_set.all()
    context = {'post': post,
               'form': form,
               'comment_list': comment_list
               }
    return render(request, 'blog/detail.html', context=context)